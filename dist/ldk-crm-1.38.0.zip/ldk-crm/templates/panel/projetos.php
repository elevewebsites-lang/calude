<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$view  = isset( $_GET['ver'] ) ? sanitize_key( $_GET['ver'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cols  = lk_columns();
$ready = lk_ready_column();

$actions  = '<div class="seg"><a href="' . esc_url( lk_panel_url( 'pedidos' ) ) . '" class="' . ( '' === $view ? 'is-active' : '' ) . '">Quadro</a><a href="' . esc_url( lk_panel_url( 'pedidos', 0, array( 'ver' => 'todos' ) ) ) . '" class="' . ( 'todos' === $view ? 'is-active' : '' ) . '">Lista</a><a href="' . esc_url( lk_panel_url( 'pedidos', 0, array( 'ver' => 'arquivados' ) ) ) . '" class="' . ( 'arquivados' === $view ? 'is-active' : '' ) . '">Arquivados</a></div>';
$actions .= '<button type="button" class="btn btn--ghost" data-open="novo-pedido">' . lk_icon( 'mais', 16 ) . '<span>Pedido manual</span></button>';
$actions .= '<a class="btn btn--primary" href="' . esc_url( lk_panel_url( 'orcamento' ) ) . '">' . lk_icon( 'mais', 16 ) . '<span>Novo orçamento</span></a>';
lk_panel_start( 'Pedidos', 'pedidos', $actions );

if ( '' === $view ) :
	$projects = lk_projects( 'p.archived = 0' );
	$internal = lk_board_internal();
	$board    = array();
	foreach ( $internal as $slug => $name ) {
		$board[ $slug ] = array( $name, 'internal' );
	}
	foreach ( $cols as $slug => $name ) {
		$board[ $slug ] = array( $name, 'stage' );
	}
	$by_col = array_fill_keys( array_keys( $board ), array() );
	$first  = array_keys( $cols )[0];
	foreach ( $projects as $p ) {
		if ( ! empty( $p->board_col ) && isset( $internal[ $p->board_col ] ) ) {
			$by_col[ $p->board_col ][] = $p;
		} else {
			$by_col[ isset( $cols[ $p->status ] ) ? $p->status : $first ][] = $p;
		}
	}
	$last_stage = lk_last_column();
	?>
	<p class="muted small hint">Arraste os cards entre as etapas. Em <strong><?php echo esc_html( $cols[ $ready ] ?? 'Pronto' ); ?></strong>, o cliente recebe o e-mail "seu pedido está pronto" com as fotos, e o card mostra o botão de WhatsApp.</p>
	<div class="kanban kanban--editable" data-kanban="project">
		<?php foreach ( $board as $slug => $info ) : ?>
			<?php list( $name, $kind ) = $info; ?>
			<section class="kcol<?php echo 'internal' === $kind ? ' kcol--internal' : ''; ?><?php echo $slug === $ready ? ' kcol--ready' : ''; ?>" data-col="<?php echo esc_attr( $slug ); ?>" data-kind="<?php echo esc_attr( $kind ); ?>"<?php echo $slug === $last_stage ? ' data-last' : ''; ?>>
				<header class="kcol-head">
					<h3 class="kcol-title" data-col-name title="Clique para renomear"><?php echo esc_html( $name ); ?></h3>
					<?php if ( 'internal' === $kind ) : ?><span class="kcol-tag" title="Coluna interna: só organiza o seu quadro.">interna</span><?php endif; ?>
					<span class="kcount"><?php echo (int) count( $by_col[ $slug ] ); ?></span>
					<span class="kcol-tools">
						<button type="button" class="kcol-btn" data-col-op="left" title="Mover para a esquerda">‹</button>
						<button type="button" class="kcol-btn" data-col-op="right" title="Mover para a direita">›</button>
						<?php if ( $slug !== $last_stage ) : ?><button type="button" class="kcol-btn" data-col-op="delete" title="Excluir coluna">×</button><?php endif; ?>
					</span>
				</header>
				<div class="kcol-body" data-status="<?php echo esc_attr( $slug ); ?>">
					<?php foreach ( $by_col[ $slug ] as $p ) : ?>
						<?php
						$photos = lk_order_photos( $p );
						$thumb  = $photos ? ( $photos[0]['thumb'] ?? $photos[0]['url'] ) : '';
						if ( ! $thumb && $p->quote_id && ( $q = lk_get( 'quotes', $p->quote_id ) ) ) { // phpcs:ignore
							$qi    = lk_json( $q->images );
							$thumb = $qi ? ( $qi[0]['thumb'] ?? $qi[0]['url'] ) : '';
						}
						$wa = $slug === $ready ? lk_order_wa_link( $p ) : '';
						?>
						<article class="kcard kcard--order" draggable="true" data-id="<?php echo (int) $p->id; ?>" data-href="<?php echo esc_url( lk_panel_url( 'pedido', $p->id ) ); ?>">
							<?php if ( $thumb ) : ?><img class="kcard-thumb" src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy"><?php endif; ?>
							<div class="kcard-top">
								<span class="badge">#<?php echo (int) $p->id; ?></span>
								<?php if ( 'pedido' !== $p->kind && '' !== $p->kind ) : ?><span class="badge badge--channel"><?php echo esc_html( lk_channels()[ $p->kind ]['name'] ?? $p->kind ); ?></span><?php endif; ?>
								<span class="badge badge--<?php echo 'envio' === $p->delivery_mode ? 'ship' : 'pickup'; ?>"><?php echo 'envio' === $p->delivery_mode ? 'Envio' : 'Retirada'; ?></span>
								<?php if ( 'internal' === $kind && isset( $cols[ $p->status ] ) ) : ?><span class="badge"><?php echo esc_html( $cols[ $p->status ] ); ?></span><?php endif; ?>
							</div>
							<h4><?php echo esc_html( $p->title ); ?></h4>
							<p class="kcard-sub"><?php echo esc_html( lk_project_client_label( $p ) ); ?></p>
							<div class="kcard-foot">
								<span class="money small"><?php echo lk_can( 'financeiro' ) ? esc_html( lk_money( $p->value ) ) : ''; ?></span>
								<?php echo lk_due_badge( $p->due_date, $last_stage === $p->status || $ready === $p->status ); // phpcs:ignore ?>
							</div>
							<?php if ( $wa ) : ?>
								<a class="btn btn--wa btn--sm btn--block kcard-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo lk_icon( 'whatsapp', 14 ); // phpcs:ignore ?><span>Avisar que está pronto</span></a>
								<?php if ( $p->ready_notified ) : ?><small class="muted kcard-note">E-mail enviado <?php echo esc_html( lk_ago( $p->ready_notified ) ); ?></small><?php endif; ?>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endforeach; ?>
		<section class="kcol kcol--add">
			<button type="button" class="kcol-add-btn" data-open="nova-coluna"><?php echo lk_icon( 'mais', 16 ); // phpcs:ignore ?><span>Coluna</span></button>
		</section>
	</div>

	<?php lk_modal_start( 'nova-coluna', 'Nova coluna' ); ?>
		<form class="stack" data-col-add>
			<?php lk_input( 'col_name', 'Nome da coluna', '', 'text', 'required maxlength="40" placeholder="Ex.: Hoje"' ); ?>
			<div class="choice-list">
				<label class="choice"><input type="radio" name="col_kind" value="internal" checked><span><strong>Coluna interna</strong><small>Só organiza o seu quadro (ex.: "Hoje", "Esta semana"). A etapa do pedido não muda e o cliente não recebe e-mail.</small></span></label>
				<label class="choice"><input type="radio" name="col_kind" value="stage"><span><strong>Etapa do pedido</strong><small>O cliente vê na área dele. Entra antes da última etapa.</small></span></label>
			</div>
			<div class="form-actions"><button type="button" class="btn btn--ghost" data-close>Cancelar</button><button type="submit" class="btn btn--primary">Criar coluna</button></div>
		</form>
	<?php lk_modal_end(); ?>
	<?php
else :
	$projects = lk_projects( 'arquivados' === $view ? 'p.archived = 1' : '1=1' );
	?>
	<div class="toolbar"><input type="search" class="filter" placeholder="Filtrar pedidos…" data-filter=".table-row"></div>
	<?php if ( ! $projects ) : ?>
		<div class="empty empty--big"><?php echo lk_icon( 'projetos', 28 ); // phpcs:ignore ?><h3>Nada por aqui</h3></div>
	<?php else : ?>
		<div class="table table--orders">
			<div class="table-row table-head"><span>Pedido</span><span>Etapa</span><span>Entrega</span><span>Valor</span><span>Lucro</span></div>
			<?php foreach ( $projects as $p ) : ?>
				<?php $cost = $p->cost_real > 0 ? $p->cost_real : $p->cost_estimated; ?>
				<a class="table-row" href="<?php echo esc_url( lk_panel_url( 'pedido', $p->id ) ); ?>">
					<span class="cell-main"><span><strong>#<?php echo (int) $p->id; ?> · <?php echo esc_html( $p->title ); ?></strong><small><?php echo esc_html( lk_project_client_label( $p ) ); ?></small></span></span>
					<span data-label="Etapa"><?php echo esc_html( $cols[ $p->status ] ?? $p->status ); ?><?php echo $p->archived ? ' <small>arquivado</small>' : ''; ?></span>
					<span data-label="Entrega"><?php echo esc_html( $p->due_date ? lk_date( $p->due_date ) : '—' ); ?></span>
					<span data-label="Valor" class="money"><?php echo lk_can( 'financeiro' ) ? esc_html( lk_money( $p->value ) ) : '—'; ?></span>
					<span data-label="Lucro" class="money"><?php echo lk_can( 'financeiro' ) && $cost > 0 ? esc_html( lk_money( $p->value - $p->ship_price - $cost ) ) : '—'; ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php
endif;

lk_modal_start( 'novo-pedido', 'Pedido manual' );
lk_form( 'order_create', 'stack' );
?>
	<p class="muted small">Para venda de balcão, feira ou marketplace (sem orçamento online).</p>
	<?php lk_input( 'title', 'O que é', '', 'text', 'required placeholder="Ex.: 10 chaveiros personalizados"' ); ?>
	<?php lk_select( 'client_id', 'Cliente', lk_client_options( '+ Cliente novo / sem cadastro' ), isset( $_GET['cliente'] ) ? absint( $_GET['cliente'] ) : '', 'data-new-client' ); // phpcs:ignore ?>
	<div class="new-client grid-2">
		<?php lk_input( 'new_name', 'Nome' ); ?>
		<?php lk_input( 'new_whatsapp', 'WhatsApp', '', 'tel', 'data-mask="phone"' ); ?>
		<?php lk_input( 'new_email', 'E-mail', '', 'email' ); ?>
		<?php lk_select( 'new_source', 'Origem', lk_list_options( 'origens' ) ); ?>
	</div>
	<div class="grid-2">
		<?php lk_input( 'value', 'Valor (R$)', '', 'text', 'inputmode="decimal" data-money' ); ?>
		<?php lk_select( 'method', 'Forma de pagamento', lk_list_options( 'metodos' ) ); ?>
		<?php lk_select( 'channel', 'Canal', array( 'pedido' => 'Direto (loja própria, WhatsApp, balcão)' ) + array_map( function ( $c ) { return $c['name']; }, lk_channels() ) ); ?>
		<?php lk_select( 'delivery_mode', 'Entrega', array( 'retirada' => 'Retirada', 'envio' => 'Envio' ) ); ?>
		<?php lk_input( 'due_date', 'Prazo', '', 'date' ); ?>
	</div>
	<?php lk_check( 'paid', 'Já está pago (vai direto para a fila)', true ); ?>
	<?php lk_input( 'notes', 'Observações', '', 'textarea', 'rows="3"' ); ?>
	<div class="form-actions"><button type="button" class="btn btn--ghost" data-close>Cancelar</button><button type="submit" class="btn btn--primary">Criar pedido</button></div>
</form>
<?php
lk_modal_end();
lk_panel_end();
